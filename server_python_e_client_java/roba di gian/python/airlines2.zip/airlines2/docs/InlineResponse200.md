# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flights** | [**List&lt;LMflightFlight&gt;**](LMflightFlight.md) |  |  [optional]
**companyname** | **String** |  |  [optional]
