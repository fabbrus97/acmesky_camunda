# NotifypaymentTransaction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **String** |  |  [optional]
**id** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
