# LMflightFlight

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**departureFrom** | **String** |  |  [optional]
**takeoff** | **String** |  |  [optional]
**destination** | **String** |  |  [optional]
**price** | [**LMflightFlightPrice**](LMflightFlightPrice.md) |  |  [optional]
**offerCode** | **String** | Codice identificativo dell&#x27;offerta |  [optional]
