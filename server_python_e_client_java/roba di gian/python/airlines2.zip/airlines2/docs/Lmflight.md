# Lmflight

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flight** | [**LMflightFlight**](LMflightFlight.md) |  |  [optional]
**companyname** | **String** |  |  [optional]
