# Body

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offerCode** | **String** | Codice identificativo dell&#x27;offerta |  [optional]
**customer** | [**NotifypaymentCustomer**](NotifypaymentCustomer.md) |  |  [optional]
**amountPayed** | [**NotifypaymentAmountPayed**](NotifypaymentAmountPayed.md) |  |  [optional]
**transaction** | [**NotifypaymentTransaction**](NotifypaymentTransaction.md) |  |  [optional]
