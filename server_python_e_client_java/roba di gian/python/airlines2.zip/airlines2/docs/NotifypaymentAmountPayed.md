# NotifypaymentAmountPayed

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**currency** | **String** |  |  [optional]
